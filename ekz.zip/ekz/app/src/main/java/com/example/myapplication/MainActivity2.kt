package com.example.myapplication

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.os.Message
import android.widget.EditText
import android.widget.TextView

private lateinit var count:TextView
private lateinit var sposob:TextView
private lateinit var oplata:TextView
private lateinit var count2: TextView
class MainActivity2 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        val chis2:String
        count = findViewById(R.id.kreditcount)
        sposob = findViewById(R.id.kreditsposob)
        oplata = findViewById(R.id.oplata)
        count2 = findViewById(R.id.srok)
        val receivedIntent: Intent = intent
        val receivedMessage: String? = receivedIntent.getStringExtra("textToTransfer")
        val receivedMessage2: String? = receivedIntent.getStringExtra("textToTransfer2")
        val receivedMessage3: String? = receivedIntent.getStringExtra("textToTransfer3")
        count.text = receivedMessage
        sposob.text = receivedMessage2
        count2.text = receivedMessage3

        var sum:Double
        val chis1:Double
        chis1 = (count.text.toString()).toDouble()

        if (sposob.text == "Ежемесячный платёж")
        {

            sum = chis1/ (count2.text.toString()).toDouble()
            oplata.text = sum.toString()
        }
        else if (sposob.text == "Годовой платёж")
        {
            sum = chis1/1
            oplata.text = sum.toString()
        }



    }


}