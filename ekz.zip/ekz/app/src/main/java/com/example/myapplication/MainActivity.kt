package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewParent
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import java.text.FieldPosition
import android.content.Context
import android.widget.Button


class MainActivity : AppCompatActivity() {

private lateinit var count: EditText
private lateinit var Myshare:SharedPreferences
private lateinit var spinner:Spinner
private lateinit var button: Button
private lateinit var count2: EditText
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        count = findViewById(R.id.count)
        spinner=findViewById(R.id.spinner)
        Myshare = getSharedPreferences("MyPref",Context.MODE_PRIVATE)
        button = findViewById(R.id.but1)
        count2 = findViewById(R.id.srok)
        button.setOnClickListener {
            val textToTransfer = count.text.toString()
            val textToTransfer2 = spinner.selectedItem.toString()
            val textToTransfer3 = count2.text.toString()
            val intent = Intent(this,MainActivity2::class.java)
            intent.putExtra("textToTransfer",textToTransfer)
            intent.putExtra("textToTransfer2",textToTransfer2)
            intent.putExtra("textToTransfer3",textToTransfer3)
            startActivity(intent)
        }


        val objects = listOf("Ипотека","Годовой платёж","Ежемесячный платёж")

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,objects)//Отображене списка
        spinner.adapter=adapter

        //Обработчик событий
        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedItem = parent?.getItemAtPosition(position).toString()

                Toast.makeText(this@MainActivity,"Способ кредита выбран",Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

    }



    //fun nextscreen(view: View)
    //{
       // val intent = Intent(this,MainActivity2::class.java)
        //startActivity(intent)
   // }
}